import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import session from "express-session";

// Extend express-session to include isAdmin
declare module "express-session" {
  interface SessionData {
    isAdmin: boolean;
  }
}

const ADMIN_CODE = "3987";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Session middleware
  app.use(
    session({
      store: storage.sessionStore,
      secret: process.env.SESSION_SECRET || "default_secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: app.get("env") === "production",
        maxAge: 1000 * 60 * 60 * 24 // 1 day
      },
    })
  );

  const requireAdmin = (req: any, res: any, next: any) => {
    if (!req.session.isAdmin) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // --- Auth Routes ---
  
  app.post(api.admin.login.path, (req, res) => {
    const { code } = req.body;
    if (code === ADMIN_CODE) {
      req.session.isAdmin = true;
      req.session.save(() => {
        res.json({ success: true });
      });
    } else {
      res.status(401).json({ message: "Invalid code" });
    }
  });

  app.get(api.admin.check.path, (req, res) => {
    res.json({ authenticated: !!req.session.isAdmin });
  });

  app.post(api.admin.logout.path, (req, res) => {
    req.session.destroy(() => {
      res.json({ success: true });
    });
  });

  // --- Project Routes ---

  app.get(api.projects.list.path, async (req, res) => {
    const projects = await storage.getProjects();
    res.json(projects);
  });

  app.get(api.settings.get.path, async (req, res) => {
    const settings = await storage.getSettings();
    res.json(settings);
  });

  app.put(api.settings.update.path, requireAdmin, async (req, res) => {
    try {
      const input = api.settings.update.input.parse(req.body);
      const settings = await storage.updateSettings(input);
      res.json(settings);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.post(api.projects.create.path, requireAdmin, async (req, res) => {
    try {
      const input = api.projects.create.input.parse(req.body);
      const project = await storage.createProject(input);
      res.status(201).json(project);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.put(api.projects.update.path, requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const input = api.projects.update.input.parse(req.body);
      const project = await storage.updateProject(id, input);
      res.json(project);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.projects.delete.path, requireAdmin, async (req, res) => {
    const id = parseInt(req.params.id);
    await storage.deleteProject(id);
    res.status(204).send();
  });

  // Seed data if empty
  const existing = await storage.getProjects();
  if (existing.length === 0) {
    await storage.createProject({
      title: "Neon Dreams E-Commerce",
      description: "A futuristic shopping experience built with React and Three.js.",
      imageUrl: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80",
      projectUrl: "https://example.com"
    });
    await storage.createProject({
      title: "Zenith Architecture",
      description: "Minimalist portfolio for an award-winning architecture firm.",
      imageUrl: "https://images.unsplash.com/photo-1487958449943-2429e8be8625?auto=format&fit=crop&q=80",
      projectUrl: "https://example.com"
    });
    await storage.createProject({
      title: "Flow State App",
      description: "Productivity application focused on deep work and focus.",
      imageUrl: "https://images.unsplash.com/photo-1555421689-491a97ff2040?auto=format&fit=crop&q=80",
      projectUrl: "https://example.com"
    });
  }

  // Seed settings if empty
  const settings = await storage.getSettings();
  if (settings.contactEmail === "hello@justachild.com") {
    await storage.updateSettings({ contactEmail: "andysihoon0204@gmail.com" });
  }

  return httpServer;
}
