import { db } from "./db";
import { projects, siteSettings, type Project, type InsertProject, type SiteSettings, type InsertSiteSettings } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project>;
  deleteProject(id: number): Promise<void>;
  getSettings(): Promise<SiteSettings>;
  updateSettings(updates: Partial<InsertSiteSettings>): Promise<SiteSettings>;
  sessionStore: any; // For express-session
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor(sessionStore: any) {
    this.sessionStore = sessionStore;
  }

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.createdAt));
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db
      .insert(projects)
      .values(insertProject)
      .returning();
    return project;
  }

  async updateProject(id: number, updates: Partial<InsertProject>): Promise<Project> {
    const [project] = await db
      .update(projects)
      .set(updates)
      .where(eq(projects.id, id))
      .returning();
    return project;
  }

  async deleteProject(id: number): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  async getSettings(): Promise<SiteSettings> {
    const [settings] = await db.select().from(siteSettings);
    if (!settings) {
      const [newSettings] = await db.insert(siteSettings).values({}).returning();
      return newSettings;
    }
    return settings;
  }

  async updateSettings(updates: Partial<InsertSiteSettings>): Promise<SiteSettings> {
    const settings = await this.getSettings();
    const [updated] = await db
      .update(siteSettings)
      .set(updates)
      .where(eq(siteSettings.id, settings.id))
      .returning();
    return updated;
  }
}

// We'll initialize storage in index.ts or routes.ts where we have the session store
// But for now, we export a factory or let index.ts handle it.
// Actually, to keep it simple and consistent with the template, we can export an instance 
// but we need the session store. 
// Let's modify index.ts to pass the session store or create it here.
// Better: Create the storage instance in routes.ts or index.ts?
// The template usually exports `storage` from here.

// We need 'connect-pg-simple' for the session store
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);
export const storage = new DatabaseStorage(
  new PostgresSessionStore({
    pool,
    createTableIfMissing: true,
  })
);
