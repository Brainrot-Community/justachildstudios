import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  projectUrl: text("project_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const siteSettings = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  heroTitle: text("hero_title").notNull().default("JustAChild Studios"),
  heroSubtitle: text("hero_subtitle").notNull().default("Creative direction for a digital world"),
  contactEmail: text("contact_email").notNull().default("hello@justachild.com"),
});

export const insertProjectSchema = createInsertSchema(projects).omit({ 
  id: true, 
  createdAt: true 
});

export const insertSiteSettingsSchema = createInsertSchema(siteSettings).omit({
  id: true
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

export type SiteSettings = typeof siteSettings.$inferSelect;
export type InsertSiteSettings = z.infer<typeof insertSiteSettingsSchema>;

// Admin auth
export const loginSchema = z.object({
  code: z.string()
});

export type LoginRequest = z.infer<typeof loginSchema>;
