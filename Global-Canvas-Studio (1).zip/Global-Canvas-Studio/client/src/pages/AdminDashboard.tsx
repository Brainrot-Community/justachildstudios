import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Plus, LogOut, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  useProjects, 
  useCreateProject, 
  useUpdateProject, 
  useDeleteProject 
} from "@/hooks/use-projects";
import { useAdminCheck, useAdminLogout } from "@/hooks/use-admin";
import { ProjectCard } from "@/components/ProjectCard";
import { ProjectForm } from "@/components/ProjectForm";
import { useToast } from "@/hooks/use-toast";
import type { Project, InsertProject } from "@shared/schema";

export default function AdminDashboard() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: auth, isLoading: authLoading, isError } = useAdminCheck();
  const { data: projects, isLoading: projectsLoading } = useProjects();
  
  const createMutation = useCreateProject();
  const updateMutation = useUpdateProject();
  const deleteMutation = useDeleteProject();
  const logoutMutation = useAdminLogout();

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && (!auth?.authenticated || isError)) {
      setLocation("/");
    }
  }, [auth, authLoading, isError, setLocation]);

  if (authLoading) return <div className="min-h-screen flex items-center justify-center bg-background text-primary">Verifying Clearance...</div>;
  if (!auth?.authenticated) return null;

  const handleCreate = async (data: InsertProject) => {
    try {
      await createMutation.mutateAsync(data);
      toast({ title: "Success", description: "Project added to portfolio." });
      setIsFormOpen(false);
    } catch (error) {
      toast({ title: "Error", description: "Failed to create project.", variant: "destructive" });
    }
  };

  const handleUpdate = async (data: InsertProject) => {
    if (!editingProject) return;
    try {
      await updateMutation.mutateAsync({ id: editingProject.id, ...data });
      toast({ title: "Success", description: "Project updated." });
      setIsFormOpen(false);
      setEditingProject(null);
    } catch (error) {
      toast({ title: "Error", description: "Failed to update project.", variant: "destructive" });
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this project? This cannot be undone.")) {
      try {
        await deleteMutation.mutateAsync(id);
        toast({ title: "Deleted", description: "Project removed from portfolio." });
      } catch (error) {
        toast({ title: "Error", description: "Failed to delete project.", variant: "destructive" });
      }
    }
  };

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    setLocation("/");
  };

  const openCreateModal = () => {
    setEditingProject(null);
    setIsFormOpen(true);
  };

  const openEditModal = (project: Project) => {
    setEditingProject(project);
    setIsFormOpen(true);
  };

  return (
    <div className="min-h-screen bg-background p-6 md:p-12">
      <header className="max-w-7xl mx-auto flex items-center justify-between mb-12">
        <div>
          <h1 className="text-3xl font-display font-bold text-gradient mb-2">Command Center</h1>
          <p className="text-muted-foreground">Manage your portfolio content.</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" onClick={() => setLocation("/")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> View Site
          </Button>
          <Button variant="ghost" className="text-muted-foreground hover:text-destructive" onClick={handleLogout}>
            <LogOut className="mr-2 h-4 w-4" /> Logout
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto">
        <div className="flex justify-end mb-8">
          <Button size="lg" onClick={openCreateModal} className="bg-primary hover:bg-primary/90 neon-glow">
            <Plus className="mr-2 h-5 w-5" /> Add New Project
          </Button>
        </div>

        {projectsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
             {[1,2,3].map(i => <div key={i} className="h-64 rounded-xl bg-muted/20 animate-pulse"/>)}
          </div>
        ) : projects?.length === 0 ? (
          <div className="text-center py-24 border border-dashed border-white/10 rounded-2xl">
            <h3 className="text-xl font-medium text-muted-foreground mb-4">No projects yet</h3>
            <Button variant="outline" onClick={openCreateModal}>Create your first one</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects?.map((project) => (
              <ProjectCard 
                key={project.id} 
                project={project} 
                isAdmin={true} 
                onEdit={openEditModal}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}
      </main>

      <ProjectForm 
        open={isFormOpen} 
        onOpenChange={(open) => {
          setIsFormOpen(open);
          if (!open) setEditingProject(null);
        }}
        onSubmit={editingProject ? handleUpdate : handleCreate}
        initialData={editingProject || undefined}
        isLoading={createMutation.isPending || updateMutation.isPending}
      />
    </div>
  );
}
