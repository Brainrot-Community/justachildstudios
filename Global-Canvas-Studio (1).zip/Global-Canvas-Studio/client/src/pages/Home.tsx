import { motion } from "framer-motion";
import { ArrowDown, Github, Linkedin, Mail, Twitter } from "lucide-react";
import { useProjects } from "@/hooks/use-projects";
import { ProjectCard } from "@/components/ProjectCard";
import { Button } from "@/components/ui/button";

export default function Home() {
  const { data: projects, isLoading } = useProjects();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Abstract Background Elements */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] bg-accent/10 rounded-full blur-[120px]" />
      </div>

      {/* Hero Section */}
      <section className="relative h-screen flex flex-col items-center justify-center z-10 px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="text-center"
        >
          <h2 className="text-primary font-medium tracking-widest mb-4 uppercase text-sm md:text-base">Creative Portfolio</h2>
          <h1 className="text-5xl md:text-8xl font-display font-bold mb-6 leading-tight">
            JustAChild <br /> 
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-gray-200 to-gray-500">Studios</span>
          </h1>
          <p className="max-w-xl mx-auto text-muted-foreground text-lg md:text-xl mb-10">
            Crafting digital experiences that bridge the gap between imagination and reality. 
            We build worlds, not just websites.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="absolute bottom-12 animate-bounce"
        >
          <ArrowDown className="text-muted-foreground w-8 h-8" />
        </motion.div>
      </section>

      {/* Portfolio Grid */}
      <section id="work" className="relative z-10 py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="flex items-end justify-between mb-16"
        >
          <div>
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">Selected Work</h2>
            <div className="h-1 w-24 bg-primary rounded-full" />
          </div>
          <p className="hidden md:block text-muted-foreground max-w-xs text-right">
            A curated collection of projects from across the globe.
          </p>
        </motion.div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((n) => (
              <div key={n} className="h-96 rounded-xl bg-muted/20 animate-pulse" />
            ))}
          </div>
        ) : (
          <motion.div 
            variants={container}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {projects?.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </motion.div>
        )}
      </section>

      {/* Contact / Footer */}
      <section className="relative z-10 py-24 border-t border-white/5 bg-black/20 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-display font-bold mb-8">Let's Create Something Amazing</h2>
          <p className="text-muted-foreground mb-12 text-lg">
            Have a project in mind? We're currently accepting new clients for {new Date().getFullYear()}.
          </p>
          
          <div className="flex justify-center gap-6 mb-16">
            <Button variant="outline" size="lg" className="rounded-full h-12 w-12 p-0 border-white/10 hover:bg-white/10 hover:text-primary transition-colors">
              <Github className="w-5 h-5" />
            </Button>
            <Button variant="outline" size="lg" className="rounded-full h-12 w-12 p-0 border-white/10 hover:bg-white/10 hover:text-primary transition-colors">
              <Twitter className="w-5 h-5" />
            </Button>
            <Button variant="outline" size="lg" className="rounded-full h-12 w-12 p-0 border-white/10 hover:bg-white/10 hover:text-primary transition-colors">
              <Linkedin className="w-5 h-5" />
            </Button>
            <Button variant="outline" size="lg" className="rounded-full h-12 w-12 p-0 border-white/10 hover:bg-white/10 hover:text-primary transition-colors">
              <Mail className="w-5 h-5" />
            </Button>
          </div>

          <p className="text-sm text-muted-foreground font-mono">
            &copy; {new Date().getFullYear()} JustAChild Studios. All rights reserved.
          </p>
        </div>
      </section>
    </div>
  );
}
