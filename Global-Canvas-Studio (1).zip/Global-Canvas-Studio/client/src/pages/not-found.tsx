import { Link } from "wouter";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-background text-foreground">
      <div className="glass-card p-12 rounded-2xl text-center max-w-md mx-4">
        <AlertTriangle className="h-16 w-16 text-destructive mx-auto mb-6" />
        <h1 className="text-4xl font-bold font-display mb-4 text-gradient">404</h1>
        <p className="text-xl text-muted-foreground mb-8">
          The page you're looking for has been lost in the digital void.
        </p>
        <Link href="/">
          <Button size="lg" className="w-full neon-glow">
            Return to Base
          </Button>
        </Link>
      </div>
    </div>
  );
}
