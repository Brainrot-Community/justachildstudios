import { motion } from "framer-motion";
import { ExternalLink, Trash2, Edit } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Project } from "@shared/schema";

interface ProjectCardProps {
  project: Project;
  isAdmin?: boolean;
  onEdit?: (project: Project) => void;
  onDelete?: (id: number) => void;
}

export function ProjectCard({ project, isAdmin, onEdit, onDelete }: ProjectCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -5 }}
      className="group relative glass-card rounded-xl overflow-hidden flex flex-col h-full"
    >
      <div className="relative aspect-video overflow-hidden bg-muted">
        {/* Placeholder gradient if image fails or loading, though actual img is overlaid */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20" />
        <img 
          src={project.imageUrl} 
          alt={project.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          onError={(e) => {
            e.currentTarget.src = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop"; // Abstract fallback
          }}
        />
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-4">
          {project.projectUrl && (
            <Button asChild variant="secondary" className="rounded-full">
              <a href={project.projectUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="mr-2 h-4 w-4" /> Visit
              </a>
            </Button>
          )}
        </div>
        
        {isAdmin && (
          <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <Button size="icon" variant="secondary" className="h-8 w-8 rounded-full" onClick={() => onEdit?.(project)}>
              <Edit className="h-4 w-4" />
            </Button>
            <Button size="icon" variant="destructive" className="h-8 w-8 rounded-full" onClick={() => onDelete?.(project.id)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      <div className="p-6 flex flex-col flex-grow">
        <h3 className="font-display text-xl font-bold mb-2 group-hover:text-primary transition-colors">{project.title}</h3>
        <p className="text-muted-foreground text-sm leading-relaxed flex-grow">{project.description}</p>
      </div>
      
      {/* Decorative gradient line at bottom */}
      <div className="h-1 w-full bg-gradient-to-r from-primary via-purple-500 to-accent transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
    </motion.div>
  );
}
