import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useAdminLogin, useAdminCheck } from "@/hooks/use-admin";
import { useToast } from "@/hooks/use-toast";

export function AdminGate() {
  const [open, setOpen] = useState(false);
  const [code, setCode] = useState("");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const { data: authStatus } = useAdminCheck();
  const loginMutation = useAdminLogin();

  // Listen for Ctrl+Z
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
        e.preventDefault();
        setOpen(true);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await loginMutation.mutateAsync({ code });
      toast({ title: "Welcome back, master.", className: "bg-primary text-white border-none" });
      setOpen(false);
      setCode("");
      setLocation("/admin");
    } catch (err) {
      toast({ 
        title: "Access Denied", 
        description: "That code is incorrect.",
        variant: "destructive" 
      });
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-black/90 border-primary/20 text-white backdrop-blur-xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center font-display text-2xl text-gradient">System Override</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleLogin} className="space-y-4 pt-4">
            <Input
              type="password"
              placeholder="Enter Access Code"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="bg-white/5 border-white/10 text-center text-lg tracking-[0.5em] focus:border-primary/50 focus:ring-primary/20"
              autoFocus
            />
            <Button 
              type="submit" 
              className="w-full bg-primary hover:bg-primary/80 neon-glow"
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? "Decrypting..." : "Access Mainframe"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
