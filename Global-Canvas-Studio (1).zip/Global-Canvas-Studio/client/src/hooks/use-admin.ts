import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type LoginRequest } from "@shared/routes";

// GET /api/admin/check
export function useAdminCheck() {
  return useQuery({
    queryKey: [api.admin.check.path],
    queryFn: async () => {
      const res = await fetch(api.admin.check.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to check auth status");
      return api.admin.check.responses[200].parse(await res.json());
    },
    retry: false,
    staleTime: 0, // Always check fresh
  });
}

// POST /api/admin/login
export function useAdminLogin() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: LoginRequest) => {
      const res = await fetch(api.admin.login.path, {
        method: api.admin.login.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 401) throw new Error("Invalid code");
        throw new Error("Login failed");
      }

      return api.admin.login.responses[200].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.admin.check.path] }),
  });
}

// POST /api/admin/logout
export function useAdminLogout() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.admin.logout.path, {
        method: api.admin.logout.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Logout failed");
      return api.admin.logout.responses[200].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.admin.check.path] }),
  });
}
