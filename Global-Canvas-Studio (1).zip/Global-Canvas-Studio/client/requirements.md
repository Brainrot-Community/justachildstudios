## Packages
framer-motion | Essential for the "creative" feel, scroll reveals, and smooth transitions
react-icons | Additional icons if Lucide doesn't cover everything (optional, sticking to Lucide mostly)

## Notes
Tailwind Config:
- Add custom fonts 'Space Grotesk' (display) and 'Inter' (body)
- Add neon accent colors
- Add animation keyframes for "breathing" neon effects
